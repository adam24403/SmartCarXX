import java.time.LocalDate;

public class SmartTripper extends Petrol {
    private static final double HOURLY_RATE = 12;
    private static final double DAILY_RATE = 60;

    public SmartTripper(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
    }

    @Override
    public double getHourlyRate() {
        return HOURLY_RATE;
    }

    @Override
    public double getDailyRate() {
        return DAILY_RATE;
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        return 0;
    }
}