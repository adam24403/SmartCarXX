public class Employee extends Person {
    private int empNo;

    public Employee(String firstName, String lastName, String email, int empNo) {
        super(firstName, lastName, email);
        this.empNo = empNo;
    }

    public int getempNo() {
        return empNo;
    }

    public void setempNo(int empNo) {
        this.empNo = empNo;
    }

    @Override
    public String toString() {
        return super.toString() + ", Employee ID: " + empNo;}
}
