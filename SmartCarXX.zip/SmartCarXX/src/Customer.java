//Class inheriting from person
public class Customer extends Person {
    //Declaring custNo as an Int
    private int custNo;

    public Customer(String firstName, String lastName, String email, int custNo) {
        super(firstName, lastName, email); //Calls the constructor from Person class
        this.custNo = custNo;
    }

    //Getters and Setters
    public int getCustNo() {
        return custNo;
    }

    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }

    //toString method to return customer ID
    @Override
    public String toString() {
        return super.toString() + ", Customer ID: " + custNo;
    }
}
