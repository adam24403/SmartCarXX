import java.time.LocalDate;

public class SmartElectric extends Vehicle {
    private double battery;
    private int range;
    private int efficiency;
    private static final double HOURLY_RATE = 14;
    private static final double DAILY_RATE = 70;

    public SmartElectric(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double battery, int range, int efficiency) {
        super(id, regNo, manufacturer, model, regDate, location);
        this.battery = battery;
        this.range = range;
        this.efficiency = efficiency;
    }

    public double getBattery() {
        return battery;
    }
    public void setBattery(double battery) {
        this.battery = battery;
    }

    public int getRange() {
        return range;
    }
    public void setRange(int range) {
        this.range = range;
    }

    public int getEfficiency() {
        return efficiency;
    }
    public void setEfficiency(int efficiency) {
        this.efficiency = efficiency;
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        return hours * HOURLY_RATE;
    }
}
