import java.time.LocalDate;

public abstract class SmartCity extends Petrol {
   //doubles declaring what hourly and daily rate are
    private static final double HOURLY_RATE = 11;
    private static final double DAILY_RATE = 55;

    public SmartCity(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        //formula to calculate charge on if customer goes over their free KM
        int freeKm = 50;
        double extraKmCharge = (kilometers > freeKm) ? (kilometers - freeKm) * 0.25 : 0;
        return (hours * HOURLY_RATE) + extraKmCharge;
    }
}
