import java.time.LocalDate;

public abstract class SmartVan extends Petrol {
    private static final double HOURLY_RATE = 15;
    private static final double DAILY_RATE = 85;

    public SmartVan(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
    }

    @Override
    public double getHourlyRate() {
        return HOURLY_RATE;
    }

    @Override
    public double getDailyRate() {
        return DAILY_RATE;
    }
}