import java.time.LocalDate;

public abstract class Petrol extends Vehicle {
    private double engine;
    private int co2;
    private double hourlyRate;
    private double dailyRate;

    // Constructor for Petrol vehicles
    public Petrol(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location);
        this.engine = engine;
        this.co2 = co2;
    }

    // Getter methods for engine and CO2 properties
    public double getEngine() {
        return engine;
    }

    public int getCo2() {
        return co2;
    }

    // Abstract methods to be implemented by subclasses
    public abstract double calculateRate(int hours, int kilometers);

    // Setters for hourly and daily rates
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    @Override
    public String toString() {
        return super.toString() + ", Engine Size: " + engine + "L, CO2 Rating: " + co2 + ", Hourly Rate: " + hourlyRate + ", Daily Rate: " + dailyRate;
    }
}
