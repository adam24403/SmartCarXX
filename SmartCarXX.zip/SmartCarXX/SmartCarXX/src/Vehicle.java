import java.time.LocalDate;

public abstract class Vehicle {
    private int id;
    private String regNo;
    private String manufacturer;
    private String model;
    private LocalDate regDate;
    private String location;
    private double hourlyRate;
    private double dailyRate;

    public Vehicle(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location) {
        this.id = id;
        this.regNo = regNo;
        this.manufacturer = manufacturer;
        this.model = model;
        this.regDate = regDate;
        this.location = location;
    }

    // Getter methods for Vehicle class
    public int getId() {
        return id;
    }

    public String getRegNo() {
        return regNo;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getModel() {
        return model;
    }

    public LocalDate getRegDate() {
        return regDate;
    }

    public String getLocation() {
        return location;
    }

    // Setter methods for hourly and daily rates
    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    // Getter methods for hourly and daily rates
    public double getHourlyRate() {
        return hourlyRate;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    // Abstract method to calculate rate for the vehicle
    public abstract double calculateRate(int hours, int kilometers);

    @Override
    public String toString() {
        return "ID: " + id + ", RegNo: " + regNo + ", Manufacturer: " + manufacturer + ", Model: " + model + ", Location: " + location +
                ", Hourly Rate: " + hourlyRate + ", Daily Rate: " + dailyRate;
    }
}
