public class Employee extends Person {
    private int empNo;

    public Employee(String firstName, String lastName, String email, int empNo) {
        super(firstName, lastName, email);
        this.empNo = empNo;
    }

    public int getEmpNo() {
        return empNo;
    }

    @Override
    public String toString() {
        return super.toString() + ", Employee ID: " + empNo;
    }
}
