import java.time.LocalDate;

public class SmartElectric extends Vehicle {
    private double battery;
    private int range;
    private int efficiency;

    public SmartElectric(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double battery, int range, int efficiency) {
        super(id, regNo, manufacturer, model, regDate, location);
        this.battery = battery;
        this.range = range;
        this.efficiency = efficiency;

        // Set the hourly and daily rates specific to SmartElectric
        setHourlyRate(14);
        setDailyRate(70);
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        return hours * getHourlyRate();
    }

    @Override
    public String toString() {
        return "SmartElectric - ID: " + getId() + ", RegNo: " + getRegNo() + ", Manufacturer: " + getManufacturer() +
                ", Model: " + getModel() + ", Location: " + getLocation() + ", Battery: " + battery + " kWh, Range: " + range + " km, Efficiency: " + efficiency + " Wh/km" +
                ", Hourly Rate: " + getHourlyRate() + ", Daily Rate: " + getDailyRate();
    }
}

