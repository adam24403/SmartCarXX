import java.time.LocalDate;

public class SmartVan extends Petrol {
    private static final double HOURLY_RATE = 15;
    private static final double DAILY_RATE = 85;

    public SmartVan(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
        setHourlyRate(HOURLY_RATE);  // Set the hourly rate for SmartVan
        setDailyRate(DAILY_RATE);    // Set the daily rate for SmartVan
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        return hours * getHourlyRate();
    }

    @Override
    public String toString() {
        return "SmartVan - ID: " + getId() + ", RegNo: " + getRegNo() + ", Manufacturer: " + getManufacturer() +
                ", Model: " + getModel() + ", Location: " + getLocation() + ", Engine Size: " + getEngine() + "L, CO2 Rating: " + getCo2() +
                ", Hourly Rate: " + getHourlyRate() + ", Daily Rate: " + getDailyRate();
    }
}
