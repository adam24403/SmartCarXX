import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Main {
    // Lists to hold the data for employees, customers, vehicles, and bookings
    private static final ArrayList<Employee> employees = new ArrayList<>();
    private static final ArrayList<Customer> customers = new ArrayList<>();
    private static final ArrayList<Vehicle> vehicles = new ArrayList<>();
    private static final ArrayList<Booking> bookings = new ArrayList<>();

    public static void main(String[] args) {
        // Start the program and show the main menu repeatedly
        while (true) {
            // Ask the user if they are a customer or an employee
            String userType = JOptionPane.showInputDialog(
                    "Welcome to SmartCars\n" +
                            "Are you a Customer (c) or Employee (e)? (Cancel to Exit)"
            );

            // If the user clicks cancel, exit the program
            if (userType == null) break;

            // Depending on their choice, show the relevant menu
            if (userType.equals("e")) {
                handleEmployeeMenu();  // Show employee menu
            } else if (userType.equals("c")) {
                handleCustomerMenu();  // Show customer menu
            }
        }
    }

    // Show the menu and handle the employee actions
    private static void handleEmployeeMenu() {
        while (true) {
            // Display the options available to the employee
            String choice = JOptionPane.showInputDialog(
                    "Employee Menu:\n" +
                            "1. Add a vehicle\n" +
                            "2. Update rates\n" +
                            "3. List bookings\n" +
                            "4. List customers\n" +
                            "5. List vehicles\n" +
                            "6. List employees\n" +
                            "Cancel to go back to the main menu."
            );

            // If the employee clicks cancel, exit to the main menu
            if (choice == null) return;

            // Handle different choices based on the input from the employee
            switch (choice) {
                case "1": addVehicle(); break;  // Add a new vehicle
                case "2": updateRates(); break;  // Update hourly/daily rates for vehicles
                case "3": listItems("Bookings", bookings); break;  // List all bookings
                case "4": listItems("Customers", customers); break;  // List all customers
                case "5": listItems("Vehicles", vehicles); break;  // List all vehicles
                case "6": listItems("Employees", employees); break;  // List all employees
            }
        }
    }

    // Show the menu and handle the customer actions
    private static void handleCustomerMenu() {
        while (true) {
            // Display the options available to the customer
            String choice = JOptionPane.showInputDialog(
                    "Customer Menu:\n" +
                            "1. Sign up for the service\n" +
                            "2. Book a car\n" +
                            "3. Return a car\n" +
                            "Cancel to go back to the main menu."
            );

            // If the customer clicks cancel, exit to the main menu
            if (choice == null) return;

            // Handle different choices based on the input from the customer
            switch (choice) {
                case "1": signUpCustomer(); break;  // Allow customer to sign up
                case "2": bookCar(); break;  // Book a vehicle
                case "3": returnCar(); break;  // Return a rented car
            }
        }
    }

    // Handle customer sign up by collecting customer details and adding to the list
    private static void signUpCustomer() {
        // Ask for customer details
        String firstName = JOptionPane.showInputDialog("Enter first name:");
        String lastName = JOptionPane.showInputDialog("Enter last name:");
        String email = JOptionPane.showInputDialog("Enter email:");

        // Create a customer ID based on the current size of the customer list
        int custNo = customers.size() + 1;  // Incremental customer number

        // Create the customer and add them to the list
        Customer newCustomer = new Customer(firstName, lastName, email, custNo);
        customers.add(newCustomer);
        JOptionPane.showMessageDialog(null, "Customer signed up successfully!");
    }

    // Allow customers to book a car from available vehicles
    private static void bookCar() {
        if (customers.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No customers are signed up yet.");
            return;
        }

        // Ask for the customer's email address and find the matching customer
        String customerEmail = JOptionPane.showInputDialog("Enter your email address:");
        Customer customer = null;
        for (Customer c : customers) {
            if (c.getEmail().equals(customerEmail)) {
                customer = c;
                break;
            }
        }

        // If the customer is not found, show an error message
        if (customer == null) {
            JOptionPane.showMessageDialog(null, "Customer not found.");
            return;
        }

        // Ask for the type of vehicle the customer wants to book
        String vehicleType = JOptionPane.showInputDialog("Enter vehicle type: City(c), Tripper(t), Electric(e), Van(v)");
        Vehicle availableVehicle = null;

        // Search for an available vehicle of the requested type
        for (Vehicle v : vehicles) {
            if ((vehicleType.equalsIgnoreCase("c") && v instanceof SmartCity) ||
                    (vehicleType.equalsIgnoreCase("t") && v instanceof SmartTripper) ||
                    (vehicleType.equalsIgnoreCase("e") && v instanceof SmartElectric) ||
                    (vehicleType.equalsIgnoreCase("v") && v instanceof SmartVan)) {
                availableVehicle = v;
                break;
            }
        }

        // If no matching vehicle is found, show an error message
        if (availableVehicle == null) {
            JOptionPane.showMessageDialog(null, "No available vehicles of that type.");
            return;
        }

        // Set the pick-up and return dates for the booking
        LocalDate pickUpDate = LocalDate.now();
        LocalDate returnDate = pickUpDate.plusDays(7); // Set the return date to 7 days later

        // Create a new booking and add it to the list of bookings
        Booking newBooking = new Booking(bookings.size() + 1, availableVehicle.getId(), customer.getCustNo(), pickUpDate, null, returnDate, null, "Rental Location");
        bookings.add(newBooking);

        // Show the booking ID to the customer for reference
        JOptionPane.showMessageDialog(null, "Car booked successfully! Your Booking ID is: " + newBooking.getBookingId());
    }

    // Handle the car return process
    private static void returnCar() {
        if (bookings.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No bookings available.");
            return;
        }

        // Ask for the booking ID to return the car
        String bookingIdStr = JOptionPane.showInputDialog("Enter your booking ID:");
        int bookingId = Integer.parseInt(bookingIdStr);
        Booking booking = null;

        // Search for the booking in the list of bookings
        for (Booking b : bookings) {
            if (b.getBookingId() == bookingId) {
                booking = b;
                break;
            }
        }

        // If the booking is not found, show an error message
        if (booking == null) {
            JOptionPane.showMessageDialog(null, "Booking not found.");
            return;
        }

        // Set the return time to the current time when the car is returned
        booking.setReturnTime(LocalTime.now());
        JOptionPane.showMessageDialog(null, "Car returned successfully!");
    }

    // Allow employees to add a new vehicle by collecting details from the user
    private static void addVehicle() {
        String type = JOptionPane.showInputDialog("Enter Vehicle Type: City(c), Tripper(t), Electric(e), Van(v)");
        String idStr = JOptionPane.showInputDialog("Enter Vehicle ID:");
        int id = Integer.parseInt(idStr);

        String regNo = JOptionPane.showInputDialog("Enter Registration Number:");
        String manufacturer = JOptionPane.showInputDialog("Enter Manufacturer:");
        String model = JOptionPane.showInputDialog("Enter Model:");
        String location = JOptionPane.showInputDialog("Enter Location:");

        String engineSizeStr = JOptionPane.showInputDialog("Enter Engine Size:");
        double engineSize = Double.parseDouble(engineSizeStr);

        String co2RatingStr = JOptionPane.showInputDialog("Enter CO2 Rating:");
        int co2Rating = Integer.parseInt(co2RatingStr);

        Vehicle newVehicle = null;

        // Create the appropriate vehicle object based on user input
        if (type.equals("c")) {
            newVehicle = new SmartCity(id, regNo, manufacturer, model, LocalDate.now(), location, engineSize, co2Rating);
        } else if (type.equals("t")) {
            newVehicle = new SmartTripper(id, regNo, manufacturer, model, location, engineSize, co2Rating, LocalDate.now());
        } else if (type.equals("e")) {
            String batteryStr = JOptionPane.showInputDialog("Enter Battery Capacity (kWh):");
            double battery = Double.parseDouble(batteryStr);

            String rangeStr = JOptionPane.showInputDialog("Enter Range (km):");
            int range = Integer.parseInt(rangeStr);

            String efficiencyStr = JOptionPane.showInputDialog("Enter Efficiency (Wh/km):");
            int efficiency = Integer.parseInt(efficiencyStr);

            newVehicle = new SmartElectric(id, regNo, manufacturer, model, LocalDate.now(), location, battery, range, efficiency);
        } else if (type.equals("v")) {
            newVehicle = new SmartVan(id, regNo, manufacturer, model, LocalDate.now(), location, engineSize, co2Rating);
        }

        // If a new vehicle was created, add it to the list
        if (newVehicle != null) {
            vehicles.add(newVehicle);
            JOptionPane.showMessageDialog(null, "Vehicle added successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid vehicle type.");
        }
    }

    // Allow employees to update the rates for vehicles of a specific type
    private static void updateRates() {
        String type = JOptionPane.showInputDialog("Enter Vehicle Type: City(c), Tripper(t), Electric(e), Van(v)");
        String hourlyRateStr = JOptionPane.showInputDialog("Enter New Hourly Rate:");
        String dailyRateStr = JOptionPane.showInputDialog("Enter New Daily Rate:");

        double hourlyRate = Double.parseDouble(hourlyRateStr);
        double dailyRate = Double.parseDouble(dailyRateStr);

        // Loop through the vehicles and update the rates for the selected vehicle type
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getClass().getSimpleName().equalsIgnoreCase("Smart" + type)) {
                vehicle.setHourlyRate(hourlyRate);
                vehicle.setDailyRate(dailyRate);
            }
        }

        JOptionPane.showMessageDialog(null, "Rates updated!");
    }

    // Print items to the console
    private static <List> void listItems(String title, ArrayList<List> items) {
        System.out.println(title + ":");

        // Print each item in the list
        for (List item : items) {
            System.out.println(item);
        }
    }
}
