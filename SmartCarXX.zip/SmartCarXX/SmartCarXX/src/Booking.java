import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
    private int bookingId;
    private int vehicleId;
    private int custNo;
    private LocalDate pickUpDate;
    private LocalTime pickUpTime;
    private LocalDate returnDate;
    private LocalTime returnTime;
    private String pickUpLocation;

    public Booking(int bookingId, int vehicleId, int custNo, LocalDate pickUpDate, LocalTime pickUpTime, LocalDate returnDate, LocalTime returnTime, String pickUpLocation) {
        this.bookingId = bookingId;
        this.vehicleId = vehicleId;
        this.custNo = custNo;
        this.pickUpDate = pickUpDate;
        this.pickUpTime = pickUpTime;
        this.returnDate = returnDate;
        this.returnTime = returnTime;
        this.pickUpLocation = pickUpLocation;
    }

    public int getBookingId() {
        return bookingId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public int getCustNo() {
        return custNo;
    }

    public LocalDate getPickUpDate() {
        return pickUpDate;
    }

    public LocalTime getPickUpTime() {
        return pickUpTime;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public LocalTime getReturnTime() {
        return returnTime;
    }

    public String getPickUpLocation() {
        return pickUpLocation;
    }

    @Override
    public String toString() {
        return "Booking ID: " + bookingId + ", Vehicle ID: " + vehicleId + ", Customer ID: " + custNo +
                ", Pick-Up Date: " + pickUpDate + ", Return Date: " + returnDate + ", Pick-Up Location: " + pickUpLocation;
    }

    public void setReturnTime(LocalTime returnTime) {
        this.returnTime = returnTime;
    }
}
