import java.time.LocalDate;

public class SmartTripper extends Petrol {
    private static final double HOURLY_RATE = 12;
    private static final double DAILY_RATE = 60;

    public SmartTripper(int id, String regNo, String manufacturer, String model, String location, double engine, int co2, LocalDate regDate) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
        setHourlyRate(HOURLY_RATE);  // Set the hourly rate for SmartTripper
        setDailyRate(DAILY_RATE);    // Set the daily rate for SmartTripper
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        return hours * getHourlyRate();
    }

    @Override
    public String toString() {
        return "SmartTripper - ID: " + getId() + ", RegNo: " + getRegNo() + ", Manufacturer: " + getManufacturer() +
                ", Model: " + getModel() + ", Location: " + getLocation() + ", Engine Size: " + getEngine() + "L, CO2 Rating: " + getCo2() +
                ", Hourly Rate: " + getHourlyRate() + ", Daily Rate: " + getDailyRate();
    }
}
