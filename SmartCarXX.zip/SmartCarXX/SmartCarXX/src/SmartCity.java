import java.time.LocalDate;

public class SmartCity extends Petrol {
    private static final double HOURLY_RATE = 11;
    private static final double DAILY_RATE = 55;

    public SmartCity(int id, String regNo, String manufacturer, String model, LocalDate regDate, String location, double engine, int co2) {
        super(id, regNo, manufacturer, model, regDate, location, engine, co2);
        setHourlyRate(HOURLY_RATE);  // Set the hourly rate for SmartCity
        setDailyRate(DAILY_RATE);    // Set the daily rate for SmartCity
    }

    @Override
    public double calculateRate(int hours, int kilometers) {
        int freeKm = 50;
        double extraKmCharge = (kilometers > freeKm) ? (kilometers - freeKm) * 0.25 : 0;
        return (hours * getHourlyRate()) + extraKmCharge;
    }

    @Override
    public String toString() {
        return "SmartCity - ID: " + getId() + ", RegNo: " + getRegNo() + ", Manufacturer: " + getManufacturer() +
                ", Model: " + getModel() + ", Location: " + getLocation() + ", Engine Size: " + getEngine() + "L, CO2 Rating: " + getCo2() +
                ", Hourly Rate: " + getHourlyRate() + ", Daily Rate: " + getDailyRate();
    }
}

