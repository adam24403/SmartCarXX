public class Customer extends Person {
    private int custNo;

    public Customer(String firstName, String lastName, String email, int custNo) {
        super(firstName, lastName, email);
        this.custNo = custNo;
    }

    public int getCustNo() {
        return custNo;
    }

    @Override
    public String toString() {
        return super.toString() + ", Customer ID: " + custNo;
    }
}
